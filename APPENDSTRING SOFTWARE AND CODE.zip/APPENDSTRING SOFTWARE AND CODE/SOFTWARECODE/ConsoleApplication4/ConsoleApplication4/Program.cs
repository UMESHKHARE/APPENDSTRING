﻿/*
// Sample code to perform I/O:

name = Console.ReadLine();                  // Reading input from STDIN
Console.WriteLine("Hi, {0}.", name);        // Writing output to STDOUT

// Warning: Printing unwanted or ill-formatted data to output will cause the test cases to fail
*/

// Write your code here
using System;

using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;




namespace Sample
{

    class test
    {

       
        // this code has been written by me,umesh khare at 23/10/2020

        // its logic is we will match each character of input string with out put string if character does not match
        // we will add the character in the output string, and counter will increse by one as current index in input string
        // if character of input string found in output string we will temporary store it in a string temp and process will go on untill a character comes which does not present in input string
        //then we will add that temporary temp string in output string and will add counter of appendbydoller
        
        
        
        
        public static void Main()
        {

            int nooftestcases = Convert.ToInt32(Console.ReadLine());   // no of test cases by user
            string printedstring="";
            for (int k = 0; k < nooftestcases; k++)
            {


                string[] arr = Console.ReadLine().ToString().Split(' ');  // length of string,cost of adding character,cost of appending substring input by user seperated by tabs

                string inputstring = Console.ReadLine();              // input string by user

                int dollerforadd = Convert.ToInt32(arr[1]);
                int dollerforappend = Convert.ToInt32(arr[2]);
                int lenthofinputstring = Convert.ToInt32(arr[0]);

                int minimumoutput = 0;

                string outputstring = "";
                int currentindex = 1;

                outputstring = outputstring + inputstring[0];   // as initially output string is blank so first character will always be by adding
                minimumoutput = minimumoutput + dollerforadd;   // 
                string temp = "";

                //current index is used to track at which index of input string we are getting charcter for adding or appending in output string


                for (int i = currentindex; i < inputstring.Length; i++)
                {


                    if (outputstring.Contains(inputstring[i].ToString()))
                    {

                        // this portions will execute when input string character is present in output string 


                        temp = temp + inputstring[i].ToString();
                        // this is substring of input string which will match with input string for appending


                        string nextcharacter = "";

                        if (i + 1 < inputstring.Length)
                        {

                            nextcharacter = inputstring[i + 1].ToString();
                        }
                        else
                        {
                            nextcharacter = "-1";

                        }


                        // we will add characters of input string in a temp string untill the temp string not match with input string
                        // when it does not match we will append the input string with temp string leaving next character

                        if (outputstring.Contains(temp + nextcharacter.Trim()) == false)
                        {

                            int checkappend = dollerforappend;
                            int checkadd = dollerforadd * temp.Trim().Length;

                            if (checkappend < checkadd)
                            {

                                currentindex = currentindex + temp.Trim().Length;
                                minimumoutput = minimumoutput + dollerforappend;
                                outputstring = outputstring + temp;
                                temp = "";

                            }
                            else
                            {

                                currentindex = currentindex + temp.Trim().Length;
                                minimumoutput = minimumoutput + dollerforadd;
                                outputstring = outputstring + temp;
                                temp = "";
                            }




                        }


                    }
                    else
                    {

                        // this portion will execute when character of output string not present in input so it can only be add not append

                        // output string will change by adding character also curent index


                        currentindex = currentindex + 1;
                        outputstring = outputstring + inputstring[i].ToString();
                        minimumoutput = minimumoutput + dollerforadd;
                        temp = "";



                    }




                }



                printedstring = printedstring + "\n" + minimumoutput.ToString();


            }

           

                string[] final = printedstring.Trim().Split('\n');

                for (int l = 0; l < final.Length; l++)
                {
                    System.Console.WriteLine("OUTPUT"+":"+""+final[l]);

                }

                Console.ReadLine();
        }
            
            
           



        


    }




}
