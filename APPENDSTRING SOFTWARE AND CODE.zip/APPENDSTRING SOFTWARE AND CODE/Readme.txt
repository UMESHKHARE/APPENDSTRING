according to my assingment problem1

1. i have made a console application

2. console application software is in folder 'softwareexe'  just double click this exe and check software

sample input




output: 32  (output comes as)


similarly you can check 2 test cases simultanousely
2    (sample test case)     hit enter

9 4 5   (enter string length,string add cost,string append cost all these seprated by single space) hit enter

aabacadaa( enter input string)  hit enter

5 4 5   (enter string length,string add cost,string append cost all these seprated by single space) hit enter
aabac ( enter input string)  hit enter

output 32
output 25    ouput comes as in 2 lines


3. software code is inside folder named 'softwarecode'